package com.aone.ipconnect;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.LinkAddress;
import android.net.LinkProperties;
import android.net.Network;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.net.Inet4Address;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.Collections;
import java.util.List;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(13, 21, 35);
    private static final int PANEL = Color.rgb(27, 40, 59);
    private static final int ACCENT = Color.rgb(38, 205, 166);
    private static final String BRAND = "VICKY SANDHU  •  9023020046";

    private LinearLayout root, results;
    private TextView networkInfo, status, count;
    private EditText manualIp;
    private ExecutorService scanner;
    private volatile boolean scanning = false;
    private final List<Device> devices =
            Collections.synchronizedList(new ArrayList<>());

    // Common TCP services. Discovery is best-effort, not exhaustive.
    private final int[] ports = {
            80, 443, 8080, 8000, 554, 22, 23,
            445, 3389, 9100, 37777, 34567, 5000
    };

    private static class Device {
        final String ip;
        final int port;
        Device(String ip, int port) {
            this.ip = ip;
            this.port = port;
        }
    }

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        scanner = Executors.newFixedThreadPool(32);
        buildUi();
        showNetwork();
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density);
    }

    private TextView makeText(String value, int size, int color) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        return view;
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(22), dp(18), dp(18));
        scroll.addView(root);
        setContentView(scroll);

        // App logo mark drawn in the interface.
        TextView logo = makeText("◎", 42, ACCENT);
        logo.setGravity(Gravity.CENTER);
        logo.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(logo);

        TextView title = makeText("AONE IP CONNECT", 26, Color.WHITE);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title);

        TextView subtitle = makeText(
                "LAN DEVICE DISCOVERY & MANAGEMENT", 11, ACCENT);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, dp(5), 0, dp(18));
        root.addView(subtitle);

        networkInfo = makeText("Checking network...", 14, Color.WHITE);
        addCard(networkInfo);

        Button scanButton = makeButton("SCAN MY NETWORK");
        scanButton.setOnClickListener(v -> startScan());

        status = makeText("Ready. Connect to your Wi-Fi or Ethernet network.", 13, Color.LTGRAY);
        status.setPadding(0, dp(12), 0, dp(8));
        root.addView(status);

        count = makeText("Discovered devices: 0", 17, Color.WHITE);
        count.setTypeface(Typeface.DEFAULT_BOLD);
        count.setPadding(0, dp(8), 0, dp(8));
        root.addView(count);

        results = new LinearLayout(this);
        results.setOrientation(LinearLayout.VERTICAL);
        root.addView(results);

        TextView manualTitle = makeText("ADD DEVICE MANUALLY", 14, ACCENT);
        manualTitle.setTypeface(Typeface.DEFAULT_BOLD);
        manualTitle.setPadding(0, dp(20), 0, dp(8));
        root.addView(manualTitle);

        manualIp = new EditText(this);
        manualIp.setSingleLine(true);
        manualIp.setHint("IP address, e.g. 192.168.1.50");
        manualIp.setTextColor(Color.WHITE);
        manualIp.setHintTextColor(Color.GRAY);
        manualIp.setInputType(android.text.InputType.TYPE_CLASS_TEXT);
        manualIp.setPadding(dp(12), dp(8), dp(12), dp(8));
        manualIp.setBackgroundTintList(
                android.content.res.ColorStateList.valueOf(ACCENT));
        root.addView(manualIp);

        Button addButton = makeButton("ADD IP ADDRESS");
        addButton.setOnClickListener(v -> addManualIp());

        TextView help = makeText(
                "Select OPEN LOGIN to open a device web page. Enter credentials only on devices you own or are authorized to manage.",
                12, Color.LTGRAY);
        help.setPadding(0, dp(18), 0, dp(12));
        root.addView(help);

        // Persistent in-app watermark / attribution.
        View divider = new View(this);
        divider.setBackgroundColor(Color.rgb(65, 82, 103));
        LinearLayout.LayoutParams dividerParams =
                new LinearLayout.LayoutParams(-1, dp(1));
        dividerParams.topMargin = dp(14);
        root.addView(divider, dividerParams);

        TextView watermark = makeText(BRAND, 12, ACCENT);
        watermark.setGravity(Gravity.CENTER);
        watermark.setTypeface(Typeface.DEFAULT_BOLD);
        watermark.setPadding(0, dp(15), 0, dp(8));
        root.addView(watermark);

        TextView footer = makeText("AONE IP CONNECT  •  NETWORK TOOLS", 10, Color.GRAY);
        footer.setGravity(Gravity.CENTER);
        root.addView(footer);
    }

    private void addCard(View child) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(14), dp(14), dp(14));
        card.setBackgroundColor(PANEL);
        card.addView(child);
        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(-1, -2);
        params.bottomMargin = dp(12);
        root.addView(card, params);
    }

    private Button makeButton(String label) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextColor(BG);
        button.setAllCaps(false);
        button.setTypeface(Typeface.DEFAULT_BOLD);
        button.setBackgroundTintList(
                android.content.res.ColorStateList.valueOf(ACCENT));
        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(-1, -2);
        params.topMargin = dp(8);
        root.addView(button, params);
        return button;
    }

    private void showNetwork() {
        String description = getNetworkDescription();
        networkInfo.setText(description == null
                ? "No active IPv4 Wi-Fi/Ethernet network found. Connect to your LAN and refresh."
                : "ACTIVE NETWORK\n" + description);
    }

    private String getNetworkDescription() {
        try {
            ConnectivityManager cm =
                    (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            Network active = cm.getActiveNetwork();
            if (active == null) return null;
            LinkProperties props = cm.getLinkProperties(active);
            if (props == null) return null;

            for (LinkAddress link : props.getLinkAddresses()) {
                if (link.getAddress() instanceof Inet4Address
                        && !link.getAddress().isLoopbackAddress()
                        && !link.getAddress().isLinkLocalAddress()) {
                    return link.getAddress().getHostAddress()
                            + " / prefix " + link.getPrefixLength();
                }
            }
        } catch (Exception ignored) { }
        return null;
    }

    private int[] getScanRange() throws Exception {
        ConnectivityManager cm =
                (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        Network active = cm.getActiveNetwork();
        if (active == null) throw new Exception("No active network. Connect to Wi-Fi first.");

        LinkProperties props = cm.getLinkProperties(active);
        if (props == null) throw new Exception("Cannot read network properties.");

        for (LinkAddress link : props.getLinkAddresses()) {
            if (!(link.getAddress() instanceof Inet4Address)
                    || link.getAddress().isLoopbackAddress()
                    || link.getAddress().isLinkLocalAddress()) continue;

            int prefix = link.getPrefixLength();
            // Avoid accidental scans of very large subnets.
            if (prefix < 24 || prefix > 30) {
                throw new Exception("This starter scanner supports /24 to /30 IPv4 networks. Detected /" + prefix + ".");
            }

            byte[] b = link.getAddress().getAddress();
            int ip = ((b[0] & 255) << 24) | ((b[1] & 255) << 16)
                    | ((b[2] & 255) << 8) | (b[3] & 255);
            int mask = (int) (0xFFFFFFFFL << (32 - prefix));
            int network = ip & mask;
            int hostCount = 1 << (32 - prefix);
            return new int[]{network + 1, network + hostCount - 2};
        }
        throw new Exception("No usable IPv4 address found.");
    }

    private static String intToIp(int value) {
        return ((value >>> 24) & 255) + "." + ((value >>> 16) & 255)
                + "." + ((value >>> 8) & 255) + "." + (value & 255);
    }

    private void startScan() {
        if (scanning) {
            toast("Scan already running.");
            return;
        }

        final int[] range;
        try {
            range = getScanRange();
        } catch (Exception e) {
            status.setText(e.getMessage());
            showNetwork();
            return;
        }

        scanning = true;
        devices.clear();
        results.removeAllViews();
        count.setText("Discovered devices: 0");

        final int total = range[1] - range[0] + 1;
        AtomicInteger completed = new AtomicInteger(0);
        status.setText("Scanning " + intToIp(range[0]) + " to "
                + intToIp(range[1]) + " ...");

        for (int address = range[0]; address <= range[1]; address++) {
            final String host = intToIp(address);
            scanner.execute(() -> {
                int openPort = findOpenPort(host);
                if (openPort != -1) {
                    Device device = new Device(host, openPort);
                    devices.add(device);
                    runOnUiThread(() -> {
                        addDeviceRow(device);
                        count.setText("Discovered devices: " + devices.size());
                    });
                }

                int finished = completed.incrementAndGet();
                if (finished == total) {
                    runOnUiThread(() -> {
                        scanning = false;
                        count.setText("Discovered devices: " + devices.size());
                        status.setText("Scan finished. " + total
                                + " IP addresses checked. Devices with no tested open TCP port may not appear.");
                    });
                }
            });
        }
    }

    private int findOpenPort(String host) {
        for (int port : ports) {
            try (Socket socket = new Socket()) {
                socket.connect(new InetSocketAddress(host, port), 250);
                return port;
            } catch (Exception ignored) { }
        }
        return -1;
    }

    private void addDeviceRow(Device device) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(13), dp(11), dp(13), dp(11));
        card.setBackgroundColor(PANEL);

        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(-1, -2);
        params.bottomMargin = dp(8);
        results.addView(card, params);

        TextView ip = makeText(device.ip, 18, Color.WHITE);
        ip.setTypeface(Typeface.DEFAULT_BOLD);
        card.addView(ip);

        card.addView(makeText(
                "Open TCP port: " + device.port + "  •  " + serviceName(device.port),
                12, Color.LTGRAY));

        if (isWebPort(device.port)) {
            Button open = new Button(this);
            open.setText("OPEN DEVICE LOGIN");
            open.setAllCaps(false);
            open.setOnClickListener(v -> openDevicePage(device.ip, device.port));
            card.addView(open);
        }

        Button copy = new Button(this);
        copy.setText("COPY IP ADDRESS");
        copy.setAllCaps(false);
        copy.setOnClickListener(v -> {
            ClipboardManager clipboard =
                    (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            clipboard.setPrimaryClip(ClipData.newPlainText("IP address", device.ip));
            toast("IP address copied.");
        });
        card.addView(copy);
    }

    private boolean isWebPort(int port) {
        return port == 80 || port == 443 || port == 8000
                || port == 8080 || port == 5000;
    }

    private String serviceName(int port) {
        switch (port) {
            case 80: return "HTTP web service";
            case 443: return "HTTPS web service";
            case 554: return "RTSP service (often video devices)";
            case 22: return "SSH";
            case 23: return "Telnet";
            case 445: return "SMB";
            case 3389: return "Remote Desktop";
            case 9100: return "Printer service";
            case 37777: return "Possible Dahua service";
            case 34567: return "Possible DVR service";
            case 8000: return "HTTP / device service";
            case 8080: return "Alternate HTTP";
            case 5000: return "Alternate HTTP";
            default: return "Network service";
        }
    }

    private void openDevicePage(String ip, int port) {
        String scheme = port == 443 ? "https" : "http";
        String url = scheme + "://" + ip
                + ((port == 80 || port == 443) ? "" : ":" + port);
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception e) {
            toast("No browser app available.");
        }
    }

    private void addManualIp() {
        String ip = manualIp.getText().toString().trim();
        if (!ip.matches("^(\\d{1,3}\\.){3}\\d{1,3}$")) {
            toast("Enter a valid IPv4 address.");
            return;
        }

        String[] parts = ip.split("\\.");
        for (String part : parts) {
            if (Integer.parseInt(part) > 255) {
                toast("Invalid IPv4 address.");
                return;
            }
        }

        Device device = new Device(ip, 80);
        addDeviceRow(device);
        manualIp.setText("");
        toast("IP added. Login button uses HTTP port 80.");
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (scanner != null) scanner.shutdownNow();
    }
}
